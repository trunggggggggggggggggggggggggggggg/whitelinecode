ls

nano cover.txt

nano hide_message.py

nano extract_message.py

chmod +x hide_message.py extract_message.py

python3 hide_message.py cover.txt Z stego.txt

python3 extract_message.py stego.txt

du -b cover.txt stego.txt > size.txt
